def output():
    print('小熊你好')
